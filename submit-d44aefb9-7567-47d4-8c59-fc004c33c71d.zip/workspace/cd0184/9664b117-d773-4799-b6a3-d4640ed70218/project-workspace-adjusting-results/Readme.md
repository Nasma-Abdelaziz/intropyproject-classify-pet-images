# Excercise files: 

Open the below files to continue with this excercise: 

- [adjust_results4_isadog.py](../data/adjust_results4_isadog.py)

- [adjust_results4_isadog_hints.py](../data/adjust_results4_isadog_hints.py)

