from os import listdir
import os

def get_pet_labels(image_dir):
    # Check if the directory exists
    if not os.path.isdir(image_dir):
        print(f"Error: The directory {image_dir} does not exist!")
        return None

    # Initialize an empty dictionary to store results
    results_dic = {}
    filenames = listdir(image_dir)

    # Loop through all the files in the directory
    for filename in filenames:
        # Skip hidden files (like .DS_Store on macOS)
        if filename.startswith('.'):
            continue
        
        # Ensure that the file is an image (ending with .jpg or .png)
        if not filename.endswith(('.jpg', '.png')):
            continue

        # Create a label by processing the filename
        pet_label = filename.lower().split('_')
        pet_label = ' '.join([word for word in pet_label if word.isalpha()])

        # Add the pet label to the dictionary if not already present
        if filename not in results_dic:
            results_dic[filename] = [pet_label]
        else:
            print(f"Warning: Duplicate filename {filename} detected!")

    return results_dic
