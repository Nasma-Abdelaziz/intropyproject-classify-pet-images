#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# */AIPND-revision/intropyproject-classify-pet-images/classify_images.py
#                                                                             
# PROGRAMMER: 
# DATE CREATED:                                 
# REVISED DATE: 
# PURPOSE: Create a function classify_images that uses the classifier function 
#          to create the classifier labels and then compares the classifier 
#          labels to the pet image labels. This function inputs:
#            -The Image Folder as image_dir within classify_images and function 
#             and as in_arg.dir for function call within main. 
#            -The results dictionary as results_dic within classify_images 
#             function and results for the functin call within main.
#            -The CNN model architecture as model wihtin classify_images function
#             and in_arg.arch for the function call within main. 
#           This function uses the extend function to add items to the list 
#           that's the 'value' of the results dictionary. You will be adding the
#           classifier label as the item at index 1 of the list and the comparison 
#           of the pet and classifier labels as the item at index 2 of the list.
#
## Imports classifier function for using CNN to classify images 
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# */AIPND-revision/intropyproject-classify-pet-images/classify_images.py
#                                                                             
# PROGRAMMER: 
# DATE CREATED:                                 
# REVISED DATE: 
# PURPOSE: Create a function classify_images that uses the classifier function 
#          to create the classifier labels and then compares the classifier 
#          labels to the pet image labels. This function inputs:
#            -The Image Folder as image_dir within classify_images and function 
#             and as in_arg.dir for function call within main. 
#            -The results dictionary as results_dic within classify_images 
#             function and results for the functin call within main.
#            -The CNN model architecture as model wihtin classify_images function
#             and in_arg.arch for the function call within main. 
#           This function uses the extend function to add items to the list 
#           that's the 'value' of the results dictionary. You will be adding the
#           classifier label as the item at index 1 of the list and the comparison 
#           of the pet and classifier labels as the item at index 2 of the list.
#
## Imports classifier function for using CNN to classify images 
'''from classifier import classifier 

# Define classify_images function
def classify_images(images_dir, results_dic, model):
    for filename in results_dic:
        image_path = images_dir + '/' + filename
        classifier_label = classifier(image_path, model)
        classifier_label = classifier_label.lower().strip()
        classifier_labels_list = classifier_label.split(',')
        pet_label = results_dic[filename][0]
        
        match_found = False
        for label in classifier_labels_list:
            if pet_label in label.strip():
                match_found = True
                break
        
        if match_found:
            results_dic[filename].extend([classifier_label, 1])
        else:
            results_dic[filename].extend([classifier_label, 0])
'''
from classifier import classifier

# Define classify_images function
def classify_images(images_dir, results_dic, model):
    for filename in results_dic:
        image_path = images_dir + '/' + filename
        
       
        classifier_label = classifier(image_path, model)
        classifier_label = classifier_label.lower().strip()
        classifier_labels_list = classifier_label.split(',')
        
        pet_label = results_dic[filename][0]
        
        print(f"Pet label for {filename}: {pet_label}")
        
        match_found = False
        
        for label in classifier_labels_list:
            if pet_label in label.strip():
                match_found = True
                break
        
        if match_found:
            results_dic[filename].extend([classifier_label, 1])  # إذا كان هناك تطابق
            print(f"Match found for {filename}: {classifier_label}")
        else:
            results_dic[filename].extend([classifier_label, 0])  # إذا لم يكن هناك تطابق
            print(f"No match found for {filename}: {classifier_label}")
        
        print(f"Updated results_dic for {filename}: {results_dic[filename]}")

